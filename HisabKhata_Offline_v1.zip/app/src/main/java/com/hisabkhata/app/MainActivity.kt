package com.hisabkhata.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@Entity(tableName = "transactions")
data class Transaction(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val type: String,
    val amount: Double,
    val category: String,
    val note: String,
    val date: Long = System.currentTimeMillis()
)

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions ORDER BY date DESC")
    fun all(): Flow<List<Transaction>>
    @Insert suspend fun insert(item: Transaction)
    @Delete suspend fun delete(item: Transaction)
}

@Database(entities = [Transaction::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun transactionDao(): TransactionDao
    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun get(context: android.content.Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "hisab.db").build().also { INSTANCE = it }
            }
    }
}

class MainViewModel(private val dao: TransactionDao) : ViewModel() {
    val transactions = dao.all()
    fun add(type: String, amount: Double, category: String, note: String) = viewModelScope.launch {
        dao.insert(Transaction(type = type, amount = amount, category = category, note = note))
    }
    fun delete(t: Transaction) = viewModelScope.launch { dao.delete(t) }
}

@Composable
fun appViewModel(): MainViewModel {
    val context = androidx.compose.ui.platform.LocalContext.current
    return viewModel(factory = object : androidx.lifecycle.ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            MainViewModel(AppDatabase.get(context).transactionDao()) as T
    })
}

@Composable
fun HisabApp(vm: MainViewModel) {
    val list by vm.transactions.collectAsState(initial = emptyList())
    var showAdd by remember { mutableStateOf(false) }
    val income = list.filter { it.type == "আয়" }.sumOf { it.amount }
    val expense = list.filter { it.type == "ব্যয়" }.sumOf { it.amount }
    val balance = income - expense

    Scaffold(floatingActionButton = {
        FloatingActionButton(onClick = { showAdd = true }) { Text("＋") }
    }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp)) {
            Text("হিসাব খাতা", style = MaterialTheme.typography.headlineMedium)
            Text("দৈনিক আয়–ব্যয়ের হিসাব")
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SummaryCard("মোট আয়", income, Modifier.weight(1f))
                SummaryCard("মোট ব্যয়", expense, Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("অবশিষ্ট", style = MaterialTheme.typography.titleMedium)
                    Text("৳ %.2f".format(balance), style = MaterialTheme.typography.headlineSmall)
                }
            }
            Spacer(Modifier.height(16.dp))
            Text("হিসাবের তালিকা", style = MaterialTheme.typography.titleLarge)
            LazyColumn { items(list, key = { it.id }) { t ->
                ListItem(
                    headlineContent = { Text("${t.category}  •  ৳ ${"%.2f".format(t.amount)}") },
                    supportingContent = { Text("${t.type}  ${t.note}") },
                    trailingContent = { Text(SimpleDateFormat("dd/MM", Locale.getDefault()).format(Date(t.date))) }
                )
                HorizontalDivider()
            }}
        }
    }
    if (showAdd) AddDialog({ showAdd = false }) { type, amount, cat, note ->
        vm.add(type, amount, cat, note); showAdd = false
    }
}

@Composable
fun SummaryCard(title: String, value: Double, modifier: Modifier) {
    Card(modifier) { Column(Modifier.padding(12.dp)) {
        Text(title); Text("৳ %.2f".format(value), style = MaterialTheme.typography.titleLarge)
    }}
}

@Composable
fun AddDialog(onDismiss: () -> Unit, onSave: (String, Double, String, String) -> Unit) {
    var type by remember { mutableStateOf("ব্যয়") }
    var amount by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("নতুন হিসাব") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(type == "আয়", { type = "আয়" }, label = { Text("আয়") })
                    FilterChip(type == "ব্যয়", { type = "ব্যয়" }, label = { Text("ব্যয়") })
                }
                OutlinedTextField(amount, { amount = it }, label = { Text("টাকার পরিমাণ") })
                OutlinedTextField(category, { category = it }, label = { Text("ক্যাটাগরি") })
                OutlinedTextField(note, { note = it }, label = { Text("নোট (ঐচ্ছিক)") })
            }
        },
        confirmButton = {
            TextButton(onClick = { amount.toDoubleOrNull()?.let { onSave(type, it, category.ifBlank { "অন্যান্য" }, note) } }) { Text("সংরক্ষণ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } })
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { HisabApp(appViewModel()) } }
    }
}
